//
//  CommentTableViewCell.swift
//  Confessions
//
//  Created by Crystal Tang on 11/29/18.
//  Copyright © 2018 Ji Hwan Anthony Kim. All rights reserved.
//

import UIKit
import SnapKit

class CommentTableViewCell: UITableViewCell {
    
    var profileImage: UIImageView!
    var commentUserName: UILabel!
    var commentTextView: UILabel!
    var topSeparator: UIView!
    
    let width = UIScreen.main.bounds.width
    var height = UIScreen.main.bounds.height
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        profileImage = UIImageView()
        profileImage.layer.cornerRadius = (width*(22/414))
        profileImage.layer.masksToBounds = true
        contentView.addSubview(profileImage)
        
        commentUserName = UILabel()
        commentUserName.font = UIFont.systemFont(ofSize: (height*(12/736)), weight: .medium)
        contentView.addSubview(commentUserName)
        
        commentTextView = UILabel()
        commentTextView.backgroundColor = .white
        commentTextView.frame = CGRect(x: 50, y: 0, width: (Int(width*(362/414))), height: (Int(height*(11/736))))
        commentTextView.font = UIFont.systemFont(ofSize: 10, weight: .light)
        commentTextView.layer.cornerRadius = 10
        contentView.addSubview(commentTextView)
        
        topSeparator = UIView(frame: CGRect(x: 0, y: 0, width: (width), height: (height*(15/736))))
        topSeparator.backgroundColor = UIColor(red: 216/256, green: 216/256, blue: 216/256, alpha: 1)
        contentView.addSubview(topSeparator)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func updateConstraints() {
        profileImage.snp.makeConstraints(){ make in
            make.top.equalToSuperview().offset(height*(38/736))
            make.leading.equalToSuperview().offset(width*(26/414))
            make.height.width.equalTo(width*(44/414))
        }

        commentUserName.snp.makeConstraints(){ make in
            make.top.equalTo(profileImage.snp.top).offset(6)
            make.leading.equalTo(profileImage.snp.trailing).offset(15)
            make.trailing.equalToSuperview().offset(-50)
            make.bottom.equalTo(profileImage.snp.bottom).offset(-6)
        }
        
        commentTextView.snp.makeConstraints(){ make in
            make.top.equalTo(commentUserName.snp.bottom).offset(12)
            make.leading.equalTo(profileImage.snp.trailing).offset(15)
            make.width.equalTo(width)
            make.height.equalTo(commentTextView)
            make.bottom.equalToSuperview()
            //make.height.equalTo(height)
        }
        super.updateConstraints()
    }
    
    func configure(for postInfo: GetComments){
        commentTextView.text = postInfo.text
        profileImage.image = UIImage(named: "cuLogoWhite")
        commentUserName.text = "Anonymous"
    }
    
}


