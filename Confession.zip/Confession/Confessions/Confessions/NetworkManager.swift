//
//  NetworkManager.swift
//  Confessions
//
//  Created by Ji Hwan Anthony Kim on 01/12/2018.
//  Copyright © 2018 Ji Hwan Anthony Kim. All rights reserved.
//

import UIKit
import Alamofire

class NetworkManager {

//    static func newPost(text: String, userName: String, longitude: Double, latitutde: Double, completion: @escaping (Post) -> Void) {
//
//
//    }
    private static let rememberDude = "http://104.196.164.65/"
    private static let apiPost = "http://104.196.164.65/api/posts/"
    private static let apiPostLocation = "http://104.196.164.65//api/posts/long={longitude}&lat={latitude}/"
    private static let registerW = "http://104.196.164.65/register/"
    private static let idPWinfo = "http://104.196.164.65/login/"
    private static let likePost = "http://104.196.164.65/api/post/{id}/vote/"
    private static let specPost = "http://104.196.164.65/api/post/{id}/"
    private static let getComm = "http://104.196.164.65/api/post/{id}/comments/"
    private static let addComment = "http://104.196.164.65/api/post/{id}/comment/"

    
    
    static func getPosts(completion: @escaping ([GetPost]) -> Void){
        Alamofire.request(apiPost, method: .get).validate().responseData { (response) in
            switch response.result {
            case .success(let data):
                // If you still want to see the JSON response
                if let json = try? JSONSerialization.jsonObject(with: data, options: .allowFragments) {
                    print(json)
                }
                // Create the JSON decoder
                let jsonDecoder = JSONDecoder()
                // Mention .convertFromSnakeCase
                // jsonDecoder.keyDecodingStrategy = .convertFromSnakeCase
                
                // Since the format of the data is { "data": { "classes": { [...] } }
                // we need to get inside those two layers of json to decode the classes data
                // into Course objects by first decoding the CourseResponse
                if let postResponse = try? jsonDecoder.decode(PostResponse.self, from: data) {
                    // Call the function we passed in to do whatever we want
                    // to the classes array (eg. show it on screen)
                    completion(postResponse.data)
                } else {
                    print("Invalid Response Data")
                }
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
    
    static func getComments(completion: @escaping ([GetComments]) -> Void){
        Alamofire.request(getComm, method: .get).validate().responseData { (response) in
            switch response.result {
            case .success(let data):
                // If you still want to see the JSON response
                if let json = try? JSONSerialization.jsonObject(with: data, options: .allowFragments) {
                    print(json)
                }
                // Create the JSON decoder
                let jsonDecoder = JSONDecoder()
                // Mention .convertFromSnakeCase
                // jsonDecoder.keyDecodingStrategy = .convertFromSnakeCase
                
                // Since the format of the data is { "data": { "classes": { [...] } }
                // we need to get inside those two layers of json to decode the classes data
                // into Course objects by first decoding the CourseResponse
                if let commentsResponse = try? jsonDecoder.decode(CommentsResponse.self, from: data) {
                    // Call the function we passed in to do whatever we want
                    // to the classes array (eg. show it on screen)
                    completion(commentsResponse.data)
                } else {
                    print("Invalid Response Data")
                }
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
    
    static func getSpecificPost(completion: @escaping ([SpecificPost]) -> Void){
        Alamofire.request(specPost, method: .get).validate().responseData { (response) in
            switch response.result {
            case .success(let data):
                // If you still want to see the JSON response
                if let json = try? JSONSerialization.jsonObject(with: data, options: .allowFragments) {
                    print(json)
                }
                // Create the JSON decoder
                let jsonDecoder = JSONDecoder()
                // Mention .convertFromSnakeCase
                // jsonDecoder.keyDecodingStrategy = .convertFromSnakeCase
                
                // Since the format of the data is { "data": { "classes": { [...] } }
                // we need to get inside those two layers of json to decode the classes data
                // into Course objects by first decoding the CourseResponse
                if let specificResponses = try? jsonDecoder.decode(SpecificResponse.self, from: data) {
                    // Call the function we passed in to do whatever we want
                    // to the classes array (eg. show it on screen)
                    completion(specificResponses.data)
                } else {
                    print("Invalid Response Data")
                }
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
    
    static func getPostsLocation(completion: @escaping ([GetPost]) -> Void){
        Alamofire.request(apiPostLocation, method: .get).validate().responseData { (response) in
            switch response.result {
            case .success(let data):
                // If you still want to see the JSON response
                if let json = try? JSONSerialization.jsonObject(with: data, options: .allowFragments) {
                    print(json)
                }
                // Create the JSON decoder
                let jsonDecoder = JSONDecoder()
                // Mention .convertFromSnakeCase
                // jsonDecoder.keyDecodingStrategy = .convertFromSnakeCase
                
                // Since the format of the data is { "data": { "classes": { [...] } }
                // we need to get inside those two layers of json to decode the classes data
                // into Course objects by first decoding the CourseResponse
                if let postResponse = try? jsonDecoder.decode(PostResponse.self, from: data) {
                    // Call the function we passed in to do whatever we want
                    // to the classes array (eg. show it on screen)
                    completion(postResponse.data)
                } else {
                    print("Invalid Response Data")
                }
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
    
    static func getSessionToken(completion: @escaping ([LoginToken]) -> Void){
        Alamofire.request(apiPostLocation, method: .get).validate().responseData { (response) in
            switch response.result {
            case .success(let data):
                // If you still want to see the JSON response
                if let json = try? JSONSerialization.jsonObject(with: data, options: .allowFragments) {
                    print(json)
                }
                // Create the JSON decoder
                let jsonDecoder = JSONDecoder()
                // Mention .convertFromSnakeCase
                // jsonDecoder.keyDecodingStrategy = .convertFromSnakeCase
                
                // Since the format of the data is { "data": { "classes": { [...] } }
                // we need to get inside those two layers of json to decode the classes data
                // into Course objects by first decoding the CourseResponse
                if let sessionToken = try? jsonDecoder.decode(tokenResponse.self, from: data) {
                    // Call the function we passed in to do whatever we want
                    // to the classes array (eg. show it on screen)
                    completion(sessionToken.data)
                } else {
                    print("Invalid Response Data")
                }
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
    
    static func newPosts(text: String, username: String, longitude: Double, latitude: Double, completion: @escaping (Post) -> Void){
        let parameters: [String:Any] = [
            "text": text,
            "username": username,
            "longitude": longitude,
            "latitude": latitude
        ]
        
        Alamofire.request(apiPost, method: .post
            , parameters: parameters, encoding: JSONEncoding.default, headers: [:]).validate().responseData{ (response) in
            switch response.result {
            case .success(let data):
                if let json = try? JSONSerialization.jsonObject(with: data, options: .allowFragments) {
                    print(json)
                }
                let jsonDecoder = JSONDecoder()
                if let user = try? jsonDecoder.decode(Post.self, from: data) {
                    completion(user)
                } else {
                    print("Invalid Response Data")
                }
            case .failure(let error):
                print(error.localizedDescription)
                }
        }
    }
    
    static func newComment(text: String, username: String, completion: @escaping (PostComment) -> Void){
        let parameters: [String:Any] = [
            "text": text,
            "username": username
        ]
        
        Alamofire.request(addComment, method: .post
            , parameters: parameters, encoding: JSONEncoding.default, headers: [:]).validate().responseData{ (response) in
                switch response.result {
                case .success(let data):
                    if let json = try? JSONSerialization.jsonObject(with: data, options: .allowFragments) {
                        print(json)
                    }
                    let jsonDecoder = JSONDecoder()
                    if let user = try? jsonDecoder.decode(PostComment.self, from: data) {
                        completion(user)
                    } else {
                        print("Invalid Response Data")
                    }
                case .failure(let error):
                    print(error.localizedDescription)
                }
        }
    }
    
    static func registerUser(email: String, password: String, completion: @escaping (Register) -> Void){
        
        let parameters: [String: String] = [
            "email": email,
            "password": password
        ]
        
        Alamofire.request(registerW, method: .post, parameters: parameters, encoding: JSONEncoding.default, headers: [:]).validate().responseData() { (response) in
            switch response.result {
            case .success(let data):
                if let json = try? JSONSerialization.jsonObject(with: data, options: .allowFragments) {
                    print(json)
                }
                let jsonDecoder = JSONDecoder()
                if let user = try? jsonDecoder.decode(Register.self, from: data) {
                    completion(user)
                } else {
                    print("Invalid Response Data")
                }
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
    
    static func loginUser(email: String, password: String, completion: @escaping (User) -> Void){
        
        let parameters: [String: String] = [
            "email": email,
            "password": password
        ]
        
        Alamofire.request(registerW, method: .post, parameters: parameters, encoding: JSONEncoding.default, headers: [:]).validate().responseData() { (response) in
            switch response.result {
            case .success(let data):
                if let json = try? JSONSerialization.jsonObject(with: data, options: .allowFragments) {
                    print(json)
                }
                let jsonDecoder = JSONDecoder()
                if let user = try? jsonDecoder.decode(User.self, from: data) {
                    completion(user)
                } else {
                    print("Invalid Response Data")
                }
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
    
    
    
    static func like(vote: Bool, completion: @escaping(LikePost)-> Void){
        let parameters: [String: Bool] = [
            "vote": vote
        ]
        
        Alamofire.request(likePost, method: .post, parameters: parameters, encoding: JSONEncoding.default, headers: [:]).validate().responseData() { (response) in
            switch response.result {
            case .success(let data):
                if let json = try? JSONSerialization.jsonObject(with: data, options: .allowFragments) {
                    print(json)
                }
                let jsonDecoder = JSONDecoder()
                if let user = try? jsonDecoder.decode(LikePost.self, from: data) {
                    completion(user)
                } else {
                    print("Invalid Response Data")
                }
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
}

