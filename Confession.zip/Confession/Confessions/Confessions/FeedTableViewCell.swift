//
//  FeedTableViewCell.swift
//  Confessions
//
//  Created by Ji Hwan Anthony Kim on 26/11/2018.
//  Copyright © 2018 Ji Hwan Anthony Kim. All rights reserved.
//

import UIKit
import SnapKit


protocol FeedTableViewCellDelegate{
    func didCommentButtonTapped(post: String)
}

protocol FeedTableViewCellDelegate2{
    func didLikeButtonTapped(post: String)
}

class FeedTableViewCell: UITableViewCell {
    
    var rowNum: Int = 0
    var topSeparator: UIView!
    var profileImage: UIImageView!
    var postUserName: UILabel!
//    var postTextView: UITextView!
    var postTextView: UILabel!
    var postP: GetPost!
    
    var heartImage: UIImageView!
    var commentImage: UIImageView!
    var heartLabel: UILabel!
    var commentLabel: UILabel!
    
    var likeButton: UIButton!
    var commentButton: UIButton!
    
    var bottomSeparator: UIView!
    var verticalSeparator: UIView!
    
    var width = UIScreen.main.bounds.width
    var height = UIScreen.main.bounds.height
    
    var delegate: FeedTableViewCellDelegate?
    var delegate2: FeedTableViewCellDelegate2?
    var postID = [Post]()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        topSeparator = UIView(frame: CGRect(x: 0, y: 0, width: (width), height: (height*(15/736))))
        topSeparator.backgroundColor = UIColor(red: 216/256, green: 216/256, blue: 216/256, alpha: 1)
        contentView.addSubview(topSeparator)
        
        bottomSeparator = UIView(frame: CGRect(x: 0, y: height*(173/736), width: width, height: width*(2/414)))
        bottomSeparator.backgroundColor = UIColor(red: 216/256, green: 216/256, blue: 216/256, alpha: 1)
        contentView.addSubview(bottomSeparator)
        
        verticalSeparator = UIView(frame: CGRect(x: width*(207/414), y: height*(173/736), width: width*(2/414), height: height*(61/736)))
        verticalSeparator.backgroundColor = UIColor(red: 216/256, green: 216/256, blue: 216/256, alpha: 1)
        contentView.addSubview(verticalSeparator)
        
        profileImage = UIImageView()
        profileImage.layer.cornerRadius = (width*(22/414))
        profileImage.layer.masksToBounds = true
        contentView.addSubview(profileImage)
        
        postUserName = UILabel()
        postUserName.font = UIFont.systemFont(ofSize: (height*(12/736)), weight: .medium)
        contentView.addSubview(postUserName)
        
        postTextView = UILabel()
        postTextView.backgroundColor = .white
        postTextView.frame = CGRect(x: 0, y: 0, width: (Int(width*(362/414))), height: (Int(height*(11/736))))
        postTextView.font = UIFont.systemFont(ofSize: 10, weight: .light)
        postTextView.numberOfLines = 20
        contentView.addSubview(postTextView)
        
        heartImage = UIImageView()
        heartImage.image = UIImage(named: "grayHeart")
        heartImage.contentMode = .scaleAspectFit
        contentView.addSubview(heartImage)
        
        commentImage = UIImageView()
        commentImage.image = UIImage(named: "Comment")
        commentImage.contentMode = .scaleAspectFit
        contentView.addSubview(commentImage)
        
        heartLabel = UILabel()
        heartLabel.font = UIFont.systemFont(ofSize: 10, weight: .ultraLight)
        contentView.addSubview(heartLabel)
        
        commentLabel = UILabel()
        commentLabel.font = UIFont.systemFont(ofSize: 10, weight: .ultraLight)
        contentView.addSubview(commentLabel)
        
        likeButton = UIButton()
        likeButton.setTitle("Like", for: .normal)
        likeButton.setTitleColor(.black, for: .normal)
        likeButton.titleLabel?.font = .systemFont(ofSize: 16, weight: .medium)
        likeButton.frame = CGRect(x: 0, y: 0, width: 206, height: 59)
        likeButton.titleLabel?.textAlignment = .center
        likeButton.addTarget(self, action: #selector(likeButtonPressed), for: .touchUpInside)
        contentView.addSubview(likeButton)
        
        commentButton = UIButton()
        commentButton.setTitle("Comment", for: .normal)
        commentButton.setTitleColor(.black, for: .normal)
        commentButton.titleLabel?.font = .systemFont(ofSize: 16, weight: .medium)
        commentButton.frame = CGRect(x: 0, y: 0, width: 206, height: 59)
        commentButton.titleLabel?.textAlignment = .center
        commentButton.addTarget(self, action: #selector(commentButtonPressed), for: .touchUpInside)
        contentView.addSubview(commentButton)
        
    }
    
    override func updateConstraints() {
        profileImage.snp.makeConstraints(){ make in
            make.top.equalToSuperview().offset(height*(38/736))
            make.leading.equalToSuperview().offset(width*(26/414))
            make.height.width.equalTo(width*(44/414))
        }

        postUserName.snp.makeConstraints(){ make in
            make.top.equalTo(profileImage.snp.top).offset(6)
            make.leading.equalTo(profileImage.snp.trailing).offset(15)
            make.trailing.equalToSuperview().offset(-50)
            make.bottom.equalTo(profileImage.snp.bottom).offset(-6)
        }
        
        postTextView.snp.makeConstraints(){ make in
            make.top.equalTo(profileImage.snp.bottom).offset(12)
            make.leading.equalToSuperview().offset(width*(26/414))
            make.trailing.equalToSuperview().offset(-width*(26/414))
//            make.height.equalTo(postTextView.intrinsicContentSize.height)
            make.bottom.equalTo(heartImage.snp.top).offset(-15)
//            make.height.equalTo(height*(45/736))
            //            make.bottom.equalTo(heartImage.snp.top).offset(height*(-10/736))
        }
        
        heartImage.snp.makeConstraints(){ make in
            make.top.equalTo(postTextView.snp.bottom).offset(height*(13/736))
            make.leading.equalToSuperview().offset(width*(29/414))
            make.height.equalTo(height*(11/736))
            make.width.equalTo(width*(12/414))
        }
        
        commentImage.snp.makeConstraints(){ make in
            make.top.equalTo(postTextView.snp.bottom).offset(height*(13/736))
            make.leading.equalToSuperview().offset(width*(76/414))
            make.height.equalTo(height*(11/736))
            make.width.equalTo(width*(12/414))
        }
        
        heartLabel.snp.makeConstraints(){ make in
            make.top.equalTo(postTextView.snp.bottom).offset(height*(14/736))
            make.leading.equalToSuperview().offset(width*(49/414))
            make.trailing.equalTo(commentImage.snp.leading).offset(-2)
            make.height.equalTo(height*(10/736))
        }
        
        commentLabel.snp.makeConstraints(){ make in
            make.top.equalTo(postTextView.snp.bottom).offset(height*(14/736))
            make.leading.equalToSuperview().offset(width*(96/414))
            make.width.equalTo(width*(25/414))
            make.height.equalTo(height*(10/736))
        }
        
        bottomSeparator.snp.makeConstraints(){ make in
            make.top.equalTo(heartImage.snp.bottom).offset(21)
            make.leading.trailing.equalToSuperview()
            make.height.equalTo(2)
        }
        
        verticalSeparator.snp.makeConstraints(){ make in
            make.top.equalTo(bottomSeparator.snp.top)
            make.leading.equalTo(width*(206/414))
            make.width.equalTo(2)
            make.height.equalTo(height*(59/736))
            make.bottom.equalToSuperview()
        }
        
        likeButton.snp.makeConstraints(){ make in
            make.top.equalTo(bottomSeparator.snp.bottom)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview().offset(width*(-207/414))
            make.height.equalTo(height*(59/736))
            make.bottom.equalToSuperview()
        }
        
        commentButton.snp.makeConstraints(){ make in
            make.top.equalTo(bottomSeparator.snp.bottom)
            make.leading.equalToSuperview().offset(width*(208/414))
            make.trailing.equalToSuperview()
            make.height.equalTo(height*(59/736))
            make.bottom.equalToSuperview()
        }
        
        super.updateConstraints()
    
    }
    
    
    func configure(for postInfo: GetPost){
        postUserName.text = postInfo.username
        profileImage.image = UIImage(named: "cuLogoWhite")
        postTextView.text = postInfo.text
        heartLabel.text = String(postInfo.score)
        commentLabel.text = String(postInfo.comment_count)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc func likeButtonPressed(){
        if (heartImage.image == UIImage(named: "grayHeart")){
            heartImage.image = UIImage(named: "Heart")
            NetworkManager.like(vote: true){ (like) in
            }
        }
        else{
            heartImage.image = UIImage(named: "grayHeart")
            NetworkManager.like(vote: false){ (like) in
            }
        }
    }
    
    
    @objc func commentButtonPressed(){
        delegate?.didCommentButtonTapped(post: postTextView.text!)
    }
    
    @objc func likeButtonTapped(){
        delegate2?.didLikeButtonTapped(post: postTextView.text!)
    }
}




