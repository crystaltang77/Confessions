//
//  NewPostViewController.swift
//  Confessions
//
//  Created by Ji Hwan Anthony Kim on 01/12/2018.
//  Copyright © 2018 Ji Hwan Anthony Kim. All rights reserved.
//

import UIKit
import SnapKit
import CoreLocation


class NewPostViewController: UIViewController, UITextViewDelegate, CLLocationManagerDelegate {
    var textView: UITextView!
    var cancelButton: UIButton!
    var doneButton: UIButton!
    var topSeparator: UIView!
    
    var width = UIScreen.main.bounds.width
    var height = UIScreen.main.bounds.height
    
    let locationManager = CLLocationManager()

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationController?.isNavigationBarHidden = true
        
        view.backgroundColor = .white
        
        self.locationManager.requestAlwaysAuthorization()
        self.locationManager.requestWhenInUseAuthorization()
        
        if CLLocationManager.locationServicesEnabled(){
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
            locationManager.startUpdatingLocation()
        }
        
        textView = UITextView()
        textView.delegate = self
        textView.backgroundColor = .white
        textView.frame = CGRect(x: 0, y: 0, width: 100, height: 100)
        textView.isScrollEnabled = true
        textView.text = "What's on Your Mind? \nShare it with Others at Cornell!"
        textView.isEditable = true
        textView.textColor = .lightGray
        textView.font = UIFont.systemFont(ofSize: 15, weight: .light)
        view.addSubview(textView)
        
        topSeparator = UIView(frame: CGRect(x: 0, y: 0, width: (width), height: (height*(15/736))))
        topSeparator.backgroundColor = UIColor(red: 216/256, green: 216/256, blue: 216/256, alpha: 1)
        view.addSubview(topSeparator)
        
        cancelButton = UIButton()
        cancelButton.tintColor = .blue
        cancelButton.setTitle("Cancel", for: .normal)
        cancelButton.setTitleColor(.red, for: .normal)
        cancelButton.titleLabel?.font = UIFont.systemFont(ofSize: 20, weight: .light)
        cancelButton.contentHorizontalAlignment = .center
        cancelButton.contentVerticalAlignment = .center
        cancelButton.addTarget(self, action: #selector(cancelClicked), for: .touchUpInside)
        view.addSubview(cancelButton)
        
        doneButton = UIButton()
        doneButton.tintColor = .blue
        doneButton.setTitle("Post", for: .normal)
        doneButton.setTitleColor(.blue, for: .normal)
        doneButton.titleLabel?.font = UIFont.systemFont(ofSize: 20, weight: .light)
        doneButton.contentHorizontalAlignment = .center
        doneButton.contentVerticalAlignment = .center
        doneButton.addTarget(self, action: #selector(postClicked), for: .touchUpInside)
        view.addSubview(doneButton)
        
        
        setUpConstraints()

        // Do any additional setup after loading the view.
    }
    
    func setUpConstraints(){
        
        cancelButton.snp.makeConstraints(){ make in
            make.top.equalTo(view.snp.top).offset(30)
            make.leading.equalTo(view.snp.leading).offset(20)
            make.width.equalTo(60)
            make.height.equalTo(60)
            make.bottom.equalTo(view.snp.top).offset(90)
        }
        
        doneButton.snp.makeConstraints(){ make in
            make.top.equalToSuperview().offset(30)
            make.trailing.equalTo(view.snp.trailing).offset(-20)
            make.leading.equalTo(view.snp.trailing).offset(-90)
            make.bottom.equalTo(view.snp.top).offset(90)
        }
        
        topSeparator.snp.makeConstraints(){ make in
            make.top.equalTo(cancelButton.snp.bottom).offset(9)
            make.leading.trailing.equalToSuperview()
            make.height.equalTo(2)
            make.bottom.equalTo(cancelButton.snp.bottom).offset(11)
        }

        textView.snp.makeConstraints(){ make in
            make.top.equalTo(cancelButton.snp.bottom).offset(20)
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
            make.bottom.equalTo(view.snp.bottom).offset(-30)
        }
    }
    
    var getLongitude: Double = 0.0
    var getLatitude: Double = 0.0
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let locationValue : CLLocationCoordinate2D = manager.location?.coordinate else {
            return
        }
        getLongitude = (locationValue.longitude)
        getLatitude = (locationValue.latitude)
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        textView.becomeFirstResponder()
        if textView.textColor == UIColor.lightGray {
            textView.text = ""
            textView.textColor = UIColor.black
        }
    }
    
    
    func textViewDidEndEditing(_ textView: UITextView) {
        if textView.text.isEmpty {
            textView.text = "What's on Your Mind? \nShare it with Others at Cornell!"
            textView.textColor = UIColor.lightGray
        }
    }
    
    @objc func cancelClicked(){
        navigationController?.popViewController(animated: true)
        self.tabBarController?.selectedIndex = 0
        textView.resignFirstResponder()
        textView.text = "What's on Your Mind? \nShare it with Others at Cornell!"
        textView.textColor = UIColor.lightGray
    }
    
    @objc func postClicked(){
        NetworkManager.newPosts(text: textView.text, username: "Anonymous", longitude: getLongitude, latitude: getLatitude){ (post) in
        }
        navigationController?.popViewController(animated: true)
        self.tabBarController?.selectedIndex = 0
        textView.resignFirstResponder()
        textView.text = "What's on Your Mind? \nShare it with Others at Cornell!"
        textView.textColor = UIColor.lightGray
    }
}
