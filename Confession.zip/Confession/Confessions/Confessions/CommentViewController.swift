//
//  CommentViewController.swift
//  Confessions
//
//  Created by Crystal Tang on 11/30/18.
//  Copyright © 2018 Ji Hwan Anthony Kim. All rights reserved.
//

import UIKit
import SnapKit

private let reuseIdentifier = "Cell"

class CommentViewController: UIViewController, UITextViewDelegate, UITableViewDataSource, UITableViewDelegate {
    
    var profileImage: UIImageView!
    var postTextView: UITextView!
    var postUserName: UILabel!
    
    var commentTextView: UITextView!//new
    var postCommentButton: UIButton!//new
    
    var commentTableView: UITableView!
//    var comments: [GetComments]!//new
    var post: Post!
    let reuseIdentifier = "commentCellReuse"
    
    var heartImage: UIImageView!
    var commentImage: UIImageView!
    var heartLabel: UILabel!
    var commentLabel: UILabel!
    
    var backButton: UIButton!
    var refreshControl: UIRefreshControl!

    var heartButton: UIButton!
    var getCommentsV = [GetComments]()
    
    
    var width = UIScreen.main.bounds.width
    var height = UIScreen.main.bounds.height
    var previousText: String = ""
    var getIDN: Int = 0
    
    
    
    weak var delegate: BackDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        
        navigationController?.isNavigationBarHidden = true
        
    
        
        refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: #selector(pulledToRefresh), for: .valueChanged)
        
        // Do any additional setup after loading the view.
        profileImage = UIImageView()
        profileImage.image = UIImage(named: "cuLogoWhite")
        profileImage.layer.cornerRadius = (width*(22/414))
        profileImage.layer.masksToBounds = true
        view.addSubview(profileImage)
        
        postTextView = UITextView()
        postTextView.backgroundColor = .white
        postTextView.frame = CGRect(x: 0, y: 0, width: 320, height: 261)
        postTextView.isScrollEnabled = true
        postTextView.font = UIFont.systemFont(ofSize: 15, weight: .light)
        postTextView.isEditable = false
        postTextView.backgroundColor = .lightGray
        view.addSubview(postTextView)
        
        postUserName = UILabel()
        postUserName.font = UIFont.systemFont(ofSize: (height*(12/736)), weight: .medium)
        postUserName.text = "Anonymous"
        view.addSubview(postUserName)
        
        commentTextView = UITextView()//new
        commentTextView.delegate = self
        commentTextView.backgroundColor = UIColor(red: 217/255, green: 217/255, blue: 217/255, alpha: 1)
        commentTextView.isEditable = true
        commentTextView.text = "Write a comment to this post!"
        commentTextView.textColor = UIColor.lightGray
        commentTextView.font = UIFont.systemFont(ofSize: 12, weight: .ultraLight)
        commentTextView.isScrollEnabled = true
        commentTextView.layer.cornerRadius = 10
        view.addSubview(commentTextView)
        
        postCommentButton = UIButton()//new
        postCommentButton.setImage(UIImage(named: "Post"), for: .normal)
        postCommentButton.addTarget(self, action: #selector(postCommentButtonPressed), for: .touchUpInside)
        view.addSubview(postCommentButton)
        
        commentTableView = UITableView(frame: .zero)
        commentTableView.delegate = self
        commentTableView.dataSource = self
//        commentTableView.backgroundColor = UIColor(red: 245/255, green: 245/255, blue: 245/255, alpha: 1)
        commentTableView.register(CommentTableViewCell.self, forCellReuseIdentifier: reuseIdentifier)
        commentTableView.rowHeight = UITableView.automaticDimension
        commentTableView.reloadData()
        commentTableView.estimatedRowHeight = 115
        commentTableView.refreshControl = refreshControl
        view.addSubview(commentTableView)
        
        
        heartImage = UIImageView()
        heartImage.image = UIImage(named: "Heart")
        heartImage.contentMode = .scaleAspectFit
        view.addSubview(heartImage)
        
        commentImage = UIImageView()
        commentImage.image = UIImage(named: "Comment")
        commentImage.contentMode = .scaleAspectFit
        view.addSubview(commentImage)
        
        heartLabel = UILabel()
        heartLabel.font = UIFont.systemFont(ofSize: 10, weight: .ultraLight)
        heartLabel.text = "100" //new
        view.addSubview(heartLabel)
        
        commentLabel = UILabel()
        commentLabel.font = UIFont.systemFont(ofSize: 10, weight: .ultraLight)
        commentLabel.text = "0" //new
        view.addSubview(commentLabel)
        
        heartButton = UIButton()
        heartButton.setImage(UIImage(named: "Like"), for: .normal)
        heartButton.addTarget(self, action: #selector(heartButtonPressed), for: .touchUpInside)
        view.addSubview(heartButton)
        
        backButton = UIButton()
        backButton.setImage(UIImage(named: "Back"), for: .normal)
        backButton.contentMode = .scaleAspectFit
        backButton.addTarget(self, action: #selector(backButtonPressed), for: .touchUpInside)
        view.addSubview(backButton)
        
        setUpConstraints()
        shootComments()
    }
    
    func setUpConstraints(){
        
        backButton.snp.makeConstraints(){ make in
            make.top.equalToSuperview().offset(height*(45/736))
            make.leading.equalToSuperview().offset(width*(20/414))
            make.height.equalTo(height*(20/736))
            make.width.equalTo(width*(35/736))
            make.trailing.equalTo(backButton.snp.leading).offset(width*(35/736))
        }
        
        profileImage.snp.makeConstraints(){ make in
            make.top.equalToSuperview().offset(height*(39/736))
            make.leading.equalTo(backButton.snp.trailing).offset(width*(20/414))
            make.height.width.equalTo(width*(40/414))
        }
        
        postUserName.snp.makeConstraints(){ make in
            make.top.equalToSuperview().offset(height*(40/736))
            make.leading.equalTo(profileImage.snp.trailing).offset(width*(15/414))
            make.height.equalTo(height*(32/736))
        }

        postTextView.snp.makeConstraints(){ make in
            make.top.equalTo(profileImage.snp.bottom).offset(height*(24/736))
            make.leading.equalToSuperview().offset(width*(36/414))
            make.trailing.equalToSuperview().offset(-width*(39/414))
            make.height.equalTo(height*(87/736))
        }

        heartImage.snp.makeConstraints(){ make in
            make.top.equalTo(postTextView.snp.bottom).offset(height*(34/736))
            make.leading.equalToSuperview().offset(width*(37/414))
            make.width.equalTo(width*(11/414))
            make.trailing.equalTo(heartImage.snp.leading).offset(width*(11/414))
            make.bottom.equalTo(heartImage.snp.top).offset(height*((12/736)))
        }

        heartLabel.snp.makeConstraints(){ make in
            make.top.equalTo(postTextView.snp.bottom).offset(height*(35/736))
            make.leading.equalTo(heartImage.snp.trailing).offset(width*(8/414))
            make.trailing.equalTo(heartLabel.snp.leading).offset(width*(25/414))
            make.height.equalTo(height*(10/736))
        }

        commentImage.snp.makeConstraints(){ make in
            make.top.equalTo(postTextView.snp.bottom).offset(height*(34/736))
            make.leading.equalTo(heartLabel.snp.trailing).offset(width*(13/414))
            make.height.equalTo(height*(12/736))
            make.trailing.equalTo(commentImage.snp.leading).offset((width*(11/414)))
        }

        commentLabel.snp.makeConstraints(){ make in
            make.top.equalTo(postTextView.snp.bottom).offset(height*(35/736))
            make.leading.equalTo(commentImage.snp.trailing).offset(width*(8/414))
            make.height.equalTo(height*(10/736))
            make.trailing.equalTo(commentImage.snp.leading).offset(width*(25/414))
        }

        heartButton.snp.makeConstraints(){ make in
            make.top.equalTo(postTextView.snp.bottom).offset(height*(25/736))
            make.trailing.equalTo(postTextView.snp.trailing).offset(-1)
            make.width.equalTo(width*(32/414))
            make.height.equalTo(height*(28/736))
        }

        commentTableView.snp.makeConstraints(){ make in
            make.top.equalTo(heartImage.snp.bottom).offset(height*(32/736))
            make.leading.trailing.equalToSuperview()
            make.bottom.equalTo(commentTextView.snp.top).offset(-10)
        }

        commentTextView.snp.makeConstraints { (make) in
            make.bottom.equalToSuperview().offset(-100)
            make.leading.equalToSuperview().offset(width*(37/414))
            make.trailing.equalTo(commentTextView.snp.leading).offset(width*(296/414))
            make.height.equalTo(height*(44/736))
        }

        postCommentButton.snp.makeConstraints{ (make) in
            make.top.equalTo(commentTextView.snp.top)
            make.leading.equalTo(commentTextView.snp.trailing).offset(width*(15/414))
            make.trailing.equalTo(postCommentButton.snp.leading).offset(width*(31/414))
            make.height.equalTo(commentTextView.snp.height)
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return getCommentsV.count
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: reuseIdentifier, for: indexPath) as! CommentTableViewCell
//        let post = getCommentsV[indexPath.row]
        let post = getCommentsV[indexPath.row]
        cell.configure(for: post)
        cell.setNeedsUpdateConstraints()
        cell.selectionStyle = .none
        return cell
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        commentTextView.becomeFirstResponder()
        if commentTextView.textColor == UIColor.lightGray {
            commentTextView.text = ""
            commentTextView.textColor = UIColor.black
        }
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        if commentTextView.text.isEmpty {
            commentTextView.text = "Write a comment to this post!"
            commentTextView.textColor = UIColor.lightGray
        }
    }
    
    func shootComments(){
        NetworkManager.getComments(){ arrayComments in
            self.getCommentsV = arrayComments
        }
        DispatchQueue.main.async {
            self.commentTableView.reloadData()
        }
    }
    
    @objc func heartButtonPressed(){//new
        if (heartImage.image == UIImage(named: "grayHeart")){
            heartImage.image = UIImage(named: "Heart")
            let heartLabelInt = Int(heartLabel.text!)! + 1
            heartLabel.text = String(heartLabelInt)
        }
        else{
            heartImage.image = UIImage(named: "grayHeart")
            let heartLabelInt = Int(heartLabel.text!)! - 1
            heartLabel.text = String(heartLabelInt)
        }
    }
    
    func postingComment(text: String, username: String){
        NetworkManager.newComment(text: text, username: username){(comment) in
        }
        shootComments()
    }
    
    @objc func backButtonPressed(){
        delegate?.goBack()
        dismiss(animated: true, completion: nil)
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc func postCommentButtonPressed(){ //new
        if (commentTextView.text != ""){
            postingComment(text: commentTextView.text, username: "Anonymous")
            commentTextView.text = "Write a Comment..."
        }
    }
    
    @objc func pulledToRefresh() {
//        getPosts()
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            self.refreshControl.endRefreshing()
        }
    }
    
    
}

