//
//  initialViewController.swift
//  Confessions
//
//  Created by Ji Hwan Anthony Kim on 28/11/2018.
//  Copyright © 2018 Ji Hwan Anthony Kim. All rights reserved.
//

import UIKit
import SnapKit

class initialViewController: UIViewController {
    var cornellImage: UIImageView!
    
    var emailImage: UIImageView!
    var passwordImage: UIImageView!
    
    var emailTextField: UITextField!
    var passwordTextFied: UITextField!
    
    var lineLabel1: UILabel!
    var lineLabel2: UILabel!
    
    var signInButton: UIButton!
    var signInGoogleButton: UIButton!
    var signUpButton: UIButton!

    
    var width = UIScreen.main.bounds.width
    var height = UIScreen.main.bounds.height
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        
        cornellImage = UIImageView()
        cornellImage.image = UIImage(named: "CornellLogo")
        cornellImage.clipsToBounds = true
        cornellImage.contentMode = .scaleAspectFill
        view.addSubview(cornellImage)
        
        emailImage = UIImageView()
        emailImage.image = UIImage(named: "Email")
        emailImage.contentMode = .scaleToFill
        view.addSubview(emailImage)
        
        passwordImage = UIImageView()
        passwordImage.image = UIImage(named: "PW")
        passwordImage.contentMode = .scaleToFill
        view.addSubview(passwordImage)
        
        emailTextField = UITextField()
        emailTextField.placeholder = "Email"
        view.addSubview(emailTextField)
        
        passwordTextFied = UITextField()
        passwordTextFied.placeholder = "Password"
        passwordTextFied.isSecureTextEntry = true
        view.addSubview(passwordTextFied)
        
        lineLabel1 = UILabel()
        lineLabel1.backgroundColor = UIColor(red: 242/256, green: 242/256, blue: 242/256, alpha: 1)
        view.addSubview(lineLabel1)
        
        lineLabel2 = UILabel()
        lineLabel2.backgroundColor = UIColor(red: 242/256, green: 242/256, blue: 242/256, alpha: 1)
        view.addSubview(lineLabel2)
        
//      ================================================================================================
        
        signInButton = UIButton(type: .system)
        signInButton.backgroundColor = UIColor(red: 241/256, green: 53/256, blue: 100/256, alpha: 1)
        signInButton.setTitle("Sign In", for: .normal)
        signInButton.setTitleColor(.white, for: .normal)
        signInButton.frame = CGRect(x: 207, y: 624, width: 232, height: 56)
        signInButton.addTarget(self, action: #selector(signInClicked), for: .touchUpInside)
        signInButton.titleLabel?.font = UIFont(name: "SFProDisplay-Semibold", size: height*(17/736))
        view.addSubview(signInButton)
        
        signInGoogleButton = UIButton(type: .system)
        signInGoogleButton.backgroundColor = UIColor(red: 241/256, green: 53/256, blue: 100/256, alpha: 1)
        signInGoogleButton.setTitle("Sign Up", for: .normal)
        signInGoogleButton.setTitleColor(.white, for: .normal)
        signInGoogleButton.frame = CGRect(x: 207, y: 624, width: 232, height: 56)
        signInGoogleButton.addTarget(self, action: #selector(signUpClicked), for: .touchUpInside)
        signInGoogleButton.titleLabel?.font = UIFont(name: "SFProDisplay-Semibold", size: height*(17/736))
        view.addSubview(signInGoogleButton)
        
//        signUpButton = UIButton(type: .system)
//        signUpButton.backgroundColor = .white
//        signUpButton.setTitle("Don't have an account? Sign Up!", for: .normal)
//        signUpButton.titleLabel?.font = .systemFont(ofSize: height*(11/736), weight: .medium)
//        signUpButton.setTitleColor(.black, for: .normal)
//        signUpButton.addTarget(self, action: #selector(signUpClicked), for: .touchUpInside)
//        view.addSubview(signUpButton)
        
        setUpConstraints()
        
        // Do any additional setup after loading the view.
    }
    
    func setUpConstraints(){
        
        cornellImage.snp.makeConstraints(){ make in
            make.top.equalTo(view.safeAreaLayoutGuide.snp.top)
            make.height.equalTo(height*(273/736))
            make.width.equalTo(width*(414/414))
        }
        
        emailImage.snp.makeConstraints(){ make in
            make.top.equalTo(cornellImage.snp.bottom).offset(height*(60/736))
            make.leading.equalToSuperview().offset(width*(102/414))
            make.width.equalTo(width*(21/414))
            make.height.equalTo(height*(14/736))
        }
        
        passwordImage.snp.makeConstraints(){ make in
            make.top.equalTo(emailImage.snp.bottom).offset(height*(55/736))
            make.leading.equalToSuperview().offset(width*(105/414))
            make.width.equalTo(width*(17/414))
            make.height.equalTo(height*(21/736))
        }
        
        emailTextField.snp.makeConstraints(){ make in
            make.top.equalTo(cornellImage.snp.bottom).offset(height*(57.9/736))
            make.leading.equalTo(emailImage.snp.trailing).offset(width*(19.3/414))
            make.width.equalTo(width*(150/414))
            make.height.equalTo(height*(20/736))
        }
        
        passwordTextFied.snp.makeConstraints(){ make in
            make.top.equalTo(emailTextField.snp.bottom).offset(height*(52.1/736))
            make.leading.equalTo(passwordImage.snp.trailing).offset(width*(20/414))
            make.width.equalTo(width*(150/414))
            make.height.equalTo(height*(20/736))
        }
        
        signInButton.snp.makeConstraints(){ make in
            make.top.equalTo(passwordTextFied.snp.bottom).offset(height*(55/736))
            make.leading.equalToSuperview().offset(width*(91/414))
            make.width.equalTo(width*(232/414))
            make.height.equalTo(height*(56/736))
        }
        
        signInGoogleButton.snp.makeConstraints(){ make in
            make.top.equalTo(signInButton.snp.bottom).offset(height*(20/736))
            make.leading.equalToSuperview().offset(width*(91/414))
            make.width.equalTo(width*(232/414))
            make.height.equalTo(height*(56/736))
        }
        
//        signUpButton.snp.makeConstraints(){ make in
//            make.top.equalTo(signInGoogleButton.snp.bottom).offset(height*(14/736))
//            make.centerX.equalToSuperview()
//            make.height.equalTo(height*(12/736))
//        }
        
        lineLabel1.frame = CGRect(x: width*(91/414), y: height*(397/736), width: width*(233/414), height: 1.1)
        lineLabel2.frame = CGRect(x: width*(91/414), y: height*(471/736), width: width*(233/414), height: 1.1)
        
    }
    @objc func signInClicked(){
        /*
            Need to add fucntion the if the account exists!
            If the account does not Exist. 
         */
        
        if (passwordTextFied.text != "" && emailTextField.text != "" ){
            NetworkManager.loginUser(email: emailTextField.text!, password: passwordTextFied.text!){ (login) in

            }
            UIApplication.shared.delegate?.window??.rootViewController = TabBarController()
        }
    }

    @objc func signUpClicked(){
        let signUpView = SignUpViewController()
        present(signUpView, animated: true, completion: nil)
    }
    

}
