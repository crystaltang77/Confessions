//
//  User.swift
//  Confessions
//
//  Created by Ji Hwan Anthony Kim on 25/11/2018.
//  Copyright © 2018 Ji Hwan Anthony Kim. All rights reserved.
//

import Foundation

struct newUser: Codable{
    var data: [User]
}

struct User: Codable{
    let session_token: String
    let session_expiration: String
    let update_token: String
    let user_id: String
    let photo_id: String
}
