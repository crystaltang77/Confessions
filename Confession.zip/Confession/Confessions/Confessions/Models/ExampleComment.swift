//
//  ExampleComment.swift
//  Confessions
//
//  Created by Ji Hwan Anthony Kim on 02/12/2018.
//  Copyright © 2018 Ji Hwan Anthony Kim. All rights reserved.
//

import Foundation

class ExampleComment{
    var text: String
    var username: String
    
    init(text: String, username: String){
        self.text = text
        self.username = username
    }
}

