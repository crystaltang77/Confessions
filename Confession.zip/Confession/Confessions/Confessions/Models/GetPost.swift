//
//  GetPost.swift
//  Confessions
//
//  Created by Ji Hwan Anthony Kim on 02/12/2018.
//  Copyright © 2018 Ji Hwan Anthony Kim. All rights reserved.
//

import Foundation

struct PostResponse: Codable{
    var data: [GetPost]
}

struct GetPost: Codable{
    let id: Int
    let score: Int
    let text: String
    let comment_count: Int
    let username: String
    let longitude: Double
    let latitude: Double
}
