//
//  Post.swift
//  Confessions
//
//  Created by Ji Hwan Anthony Kim on 01/12/2018.
//  Copyright © 2018 Ji Hwan Anthony Kim. All rights reserved.
//

import Foundation

struct Post: Codable {
    let text: String
    let userName: String
    let longitude: Double
    let latitude: Double
}
