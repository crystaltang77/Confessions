//
//  GetComments.swift
//  Confessions
//
//  Created by Ji Hwan Anthony Kim on 02/12/2018.
//  Copyright © 2018 Ji Hwan Anthony Kim. All rights reserved.
//

import Foundation

struct CommentsResponse: Codable{
    var data: [GetComments]
}

struct GetComments: Codable{
    let id: Int
    let score: Int
    let text: String
    let username: String
}

