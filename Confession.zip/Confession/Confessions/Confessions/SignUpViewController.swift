//
//  SigninViewController.swift
//  Confessions
//
//  Created by Ji Hwan Anthony Kim on 21/11/2018.
//  Copyright © 2018 Ji Hwan Anthony Kim. All rights reserved.
//

import UIKit
import SnapKit


class SignUpViewController: UIViewController {
    
    var cornellImage: UIImageView!
    
    var emailImage: UIImageView!
    var passwordImage: UIImageView!
    var password2Image: UIImageView!
    
    var emailTextField: UITextField!
    var passwordTextFied: UITextField!
    var password2TextField: UITextField!
    
    var lineLabel1: UILabel!
    var lineLabel2: UILabel!
    var lineLabel3: UILabel!
    
    var signUpButton: UIButton!
    
    var goBackSignIn: UIButton!
    
    var width = UIScreen.main.bounds.width
    var height = UIScreen.main.bounds.height
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        
        cornellImage = UIImageView()
        cornellImage.image = UIImage(named: "CornellLogo")
        cornellImage.clipsToBounds = true
        cornellImage.contentMode = .scaleAspectFill
        view.addSubview(cornellImage)
        
        emailImage = UIImageView()
        emailImage.image = UIImage(named: "Email")
        emailImage.contentMode = .scaleToFill
        view.addSubview(emailImage)
        
        passwordImage = UIImageView()
        passwordImage.image = UIImage(named: "PW")
        passwordImage.contentMode = .scaleToFill
        view.addSubview(passwordImage)
        
        password2Image = UIImageView()
        password2Image.image = UIImage(named: "PW")
        password2Image.contentMode = .scaleToFill
        view.addSubview(password2Image)
        
        emailTextField = UITextField()
        emailTextField.placeholder = "Email"
        emailTextField.font = UIFont(name: "SFProDisplay-Semibold", size: height*(17/736))
        view.addSubview(emailTextField)
        
        passwordTextFied = UITextField()
        passwordTextFied.placeholder = "Password"
        passwordTextFied.font = UIFont(name: "SFProDisplay-Semibold", size: height*(17/736))
        passwordTextFied.isSecureTextEntry = true
        view.addSubview(passwordTextFied)
        
        password2TextField = UITextField()
        password2TextField.placeholder = "Confirm Password"
        password2TextField.font = UIFont(name: "SFProDisplay-Semibold", size: height*(17/736))
        password2TextField.isSecureTextEntry = true
        view.addSubview(password2TextField)
        
        lineLabel1 = UILabel()
        lineLabel1.backgroundColor = UIColor(red: 242/256, green: 242/256, blue: 242/256, alpha: 1)
        view.addSubview(lineLabel1)
        
        lineLabel2 = UILabel()
        lineLabel2.backgroundColor = UIColor(red: 242/256, green: 242/256, blue: 242/256, alpha: 1)
        view.addSubview(lineLabel2)

        
        lineLabel3 = UILabel()
        lineLabel3.backgroundColor = UIColor(red: 242/256, green: 242/256, blue: 242/256, alpha: 1)
        view.addSubview(lineLabel3)

        
        signUpButton = UIButton(type: .system)
        signUpButton.backgroundColor = UIColor(red: 241/256, green: 53/256, blue: 100/256, alpha: 1)
        signUpButton.setTitle("Sign Up", for: .normal)
        signUpButton.setTitleColor(.white, for: .normal)
        signUpButton.frame = CGRect(x: 207, y: 624, width: 232, height: 56)
        signUpButton.titleLabel?.font = UIFont(name: "SFProDisplay-Semibold", size: height*(17/736))
        signUpButton.addTarget(self, action: #selector(signUpClicked), for: .touchUpInside)
        view.addSubview(signUpButton)
        
        goBackSignIn = UIButton(type: .system)
        goBackSignIn.backgroundColor = .white
        goBackSignIn.setTitle("Already have an account? Sign In!", for: .normal)
        goBackSignIn.titleLabel?.font = .systemFont(ofSize: height*(11/736), weight: .medium)
        goBackSignIn.setTitleColor(.black, for: .normal)
        goBackSignIn.addTarget(self, action: #selector(goBack), for: .touchUpInside)
        view.addSubview(goBackSignIn)
        
        setUpConstraints()
        
        // Do any additional setup after loading the view.
    }
    
    func setUpConstraints(){
        
        cornellImage.snp.makeConstraints(){ make in
            make.top.equalTo(view.safeAreaLayoutGuide.snp.top)
            make.height.equalTo(height*(273/736))
            make.width.equalTo(width*(414/414))
        }
        
        emailImage.snp.makeConstraints(){ make in
            make.top.equalTo(cornellImage.snp.bottom).offset(height*(60/736))
            make.leading.equalToSuperview().offset(width*(102/414))
            make.width.equalTo(width*(21/414))
            make.height.equalTo(height*(14/736))
        }
        
        passwordImage.snp.makeConstraints(){ make in
            make.top.equalTo(emailImage.snp.bottom).offset(height*(55/736))
            make.leading.equalToSuperview().offset(width*(105/414))
            make.width.equalTo(width*(17/414))
            make.height.equalTo(height*(21/736))
        }
        
        password2Image.snp.makeConstraints(){ make in
            make.top.equalTo(passwordImage.snp.bottom).offset(height*(58/736))
            make.leading.equalToSuperview().offset(width*(105/414))
            make.width.equalTo(width*(17/414))
            make.height.equalTo(height*(21/736))
        }
        
        emailTextField.snp.makeConstraints(){ make in
            make.top.equalTo(cornellImage.snp.bottom).offset(height*(57.9/736))
            make.leading.equalTo(emailImage.snp.trailing).offset(width*(19.3/414))
            make.width.equalTo(width*(150/414))
            make.height.equalTo(height*(20/736))
        }
        
        passwordTextFied.snp.makeConstraints(){ make in
            make.top.equalTo(emailTextField.snp.bottom).offset(height*(52.1/736))
            make.leading.equalTo(passwordImage.snp.trailing).offset(width*(20/414))
            make.width.equalTo(width*(150/414))
            make.height.equalTo(height*(20/736))
        }
        
        password2TextField.snp.makeConstraints(){ make in
            make.top.equalTo(passwordTextFied.snp.bottom).offset(height*(59/736))
            make.leading.equalTo(passwordImage.snp.trailing).offset(width*(20/414))
            make.width.equalTo(width*(150/414))
            make.height.equalTo(height*(20/736))
        }
        
        signUpButton.snp.makeConstraints(){ make in
            make.top.equalTo(password2TextField.snp.bottom).offset(height*(57/736))
            make.leading.equalToSuperview().offset(width*(91/414))
            make.width.equalTo(width*(232/414))
            make.bottom.equalTo(signUpButton.snp.top).offset(height*(56/736))
        }
        
        goBackSignIn.snp.makeConstraints(){ make in
            make.top.equalTo(signUpButton.snp.bottom).offset(height*(20/736))
            make.centerX.equalToSuperview()
            make.height.equalTo(height*(12/736))
        }
        lineLabel1.frame = CGRect(x: width*(91/414), y: height*(397/736), width: width*(233/414), height: 1.1)
        lineLabel2.frame = CGRect(x: width*(91/414), y: height*(471/736), width: width*(233/414), height: 1.1)
        lineLabel3.frame = CGRect(x: width*(91/414), y: height*(550/736), width: width*(233/414), height: 1.1)

    }
    @objc func signUpClicked(){
        
        if (emailTextField.text != "" && passwordTextFied.text != "" && password2TextField.text != "" && password2TextField.text == passwordTextFied.text){
            NetworkManager.registerUser(email: emailTextField.text!, password: passwordTextFied.text!){ (register) in
            }
            NetworkManager.loginUser(email: emailTextField.text!, password: passwordTextFied.text!){ (login) in
                print("user loggedin Successfully Matrix \(login.session_token)")
            }
            UIApplication.shared.delegate?.window??.rootViewController = TabBarController()
        }
        else{
            
        }
    }
    
    @objc func goBack(){
        let initialVC = initialViewController()
        present(initialVC, animated: true, completion: nil)
    }

}

