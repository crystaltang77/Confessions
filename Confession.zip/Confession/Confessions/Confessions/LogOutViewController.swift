//
//  LogOutViewController.swift
//  Confessions
//
//  Created by Ji Hwan Anthony Kim on 01/12/2018.
//  Copyright © 2018 Ji Hwan Anthony Kim. All rights reserved.
//

import UIKit

class LogOutViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationController?.isNavigationBarHidden = true
    }
}
