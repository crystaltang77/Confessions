//
//  TabBarController.swift
//  Confessions
//
//  Created by Ji Hwan Anthony Kim on 22/11/2018.
//  Copyright © 2018 Ji Hwan Anthony Kim. All rights reserved.
//

import UIKit

class TabBarController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        tabBar.barTintColor = UIColor(red: 245/255, green: 245/255, blue: 245/255, alpha: 1)
        setUpTabBar()
    }
    
    func setUpTabBar(){
        let mainFeed = UINavigationController(rootViewController: MainFeedViewController())
        let newPost = UINavigationController(rootViewController: NewPostViewController())
        let logoutPage = UINavigationController(rootViewController: initialViewController())
        mainFeed.tabBarItem.image = UIImage(named: "TabBar")?.withRenderingMode(.alwaysOriginal)
        mainFeed.title = "Home"
        
        newPost.tabBarItem.image = UIImage(named: "Write")?.withRenderingMode(.alwaysOriginal)
        newPost.title = "Post"
        
        logoutPage.tabBarItem.image = UIImage(named: "LogOut")?.withRenderingMode(.alwaysOriginal)
        logoutPage.title = "Log Out"
        
        
        viewControllers = [mainFeed, newPost, logoutPage]
    }

}
