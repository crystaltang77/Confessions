//
//  MainFeedViewController.swift
//  Confessions
//
//  Created by Ji Hwan Anthony Kim on 21/11/2018.
//  Copyright © 2018 Ji Hwan Anthony Kim. All rights reserved.
//

//https://www.paintcodeapp.com/news/ultimate-guide-to-iphone-resolutions
//https://developer.apple.com/design/human-interface-guidelines/ios/visual-design/adaptivity-and-layout/

import UIKit
import SnapKit
import Foundation
import Alamofire
import CoreLocation

protocol BackDelegate: class {
    func goBack()
}

class MainFeedViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UITextViewDelegate, CLLocationManagerDelegate{
    
    var profileImage: UIImageView!
    var postTextView: UITextView!
    var postButton: UIButton!
    
    var feedTableView: UITableView!
    var users: [User]!
    let reuseIdentifier = "feedCellReuse"
    var refreshControl: UIRefreshControl!
    
    let cellHeight: CGFloat = 250
    
    var width = UIScreen.main.bounds.width
    var height = UIScreen.main.bounds.height
    var currentLocation: CLLocation!
    
    var getPostV = [GetPost]()
    let locationManager = CLLocationManager()
 
    
    override func viewDidLoad() {
        view.backgroundColor = .white
        super.viewDidLoad()

        navigationController?.isNavigationBarHidden = true
        
        self.locationManager.requestAlwaysAuthorization()
        self.locationManager.requestWhenInUseAuthorization()
        
        if CLLocationManager.locationServicesEnabled(){
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
            locationManager.startUpdatingLocation()
        }
        
        refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: #selector(pulledToRefresh), for: .valueChanged)
        
        profileImage = UIImageView()
        profileImage.image = UIImage(named: "postProfilePicture")
        profileImage.layer.cornerRadius = (width*(22/414))
        profileImage.layer.masksToBounds = true
        view.addSubview(profileImage)
        
        
        postTextView = UITextView()
        postTextView.backgroundColor = .white
        postTextView.frame = CGRect(x: 0, y: 0, width: 320, height: 45)
        postTextView.isScrollEnabled = true
        postTextView.textColor = .lightGray
        postTextView.font = UIFont.systemFont(ofSize: 15, weight: .light)
        postTextView.text = "What's on your mind?"
        postTextView.delegate = self
        view.addSubview(postTextView)
        
        postButton = UIButton(type: .system)
        postButton.backgroundColor = UIColor(red: 241/256, green: 53/256, blue: 100/256, alpha: 1)
        postButton.setTitle("Post", for: .normal)
        postButton.setTitleColor(.white, for: .normal)
        postButton.titleLabel?.font = .systemFont(ofSize: 17, weight: .medium)
        postButton.frame = CGRect(x: 207, y: 624, width: 232, height: 56)
        postButton.addTarget(self, action: #selector(textPosted), for: .touchUpInside)
        view.addSubview(postButton)
        
        feedTableView = UITableView(frame: .zero)
        feedTableView.delegate = self
        feedTableView.dataSource = self
        feedTableView.register(FeedTableViewCell.self, forCellReuseIdentifier: reuseIdentifier)
        feedTableView.rowHeight = UITableView.automaticDimension
        feedTableView.estimatedRowHeight = 270
        feedTableView.tableFooterView = UIView()
        feedTableView.refreshControl = refreshControl
        feedTableView.reloadData()
        view.addSubview(feedTableView)
        
        setUpConstraints()
        getPosts()
//        getPostsByLocation()
    }
    
    var getLongitude: Double = 0.0
    var getLatitude: Double = 0.0
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let locationValue : CLLocationCoordinate2D = manager.location?.coordinate else {
            return
        }
        getLongitude = (locationValue.longitude)
        getLatitude = (locationValue.latitude)

    }
    
    func setUpConstraints(){
        postTextView.snp.makeConstraints(){ make in
            make.top.equalToSuperview().offset(height*(41/736))
            make.leading.equalToSuperview().offset(width*(84/414))
            make.trailing.equalToSuperview().offset(width*(-15/414))
            make.height.equalTo(height*(60/736))
        }
        
        postButton.snp.makeConstraints(){ make in
            make.top.equalTo(postTextView.snp.bottom).offset(7)
            make.leading.trailing.equalToSuperview()
            make.height.equalTo(height*(37/736))
        }
        
        feedTableView.snp.makeConstraints(){ make in
            make.top.equalTo(postButton.snp.bottom)
            make.leading.trailing.bottom.equalToSuperview()
        }
        
        profileImage.snp.makeConstraints(){ make in
            make.top.equalTo(postTextView).offset(2)
            make.leading.equalToSuperview().offset(width*(26/414))
            make.height.width.equalTo(width*(44/414))
        }
    }
    
    func getPosts(){
        NetworkManager.getPosts{ postArray in
            self.getPostV = postArray
            DispatchQueue.main.async {
                self.feedTableView.reloadData()
            }
        }
    }
    
    func getPostsByLocation(){
        NetworkManager.getPostsLocation{ postArray in
            self.getPostV = postArray
            
            DispatchQueue.main.async {
                self.feedTableView.reloadData()
            }
        }
    }
    
    func newPosts(text: String, username: String, longitude: Double, latitude: Double){
        NetworkManager.newPosts(text: text, username: username, longitude: longitude, latitude: latitude){ (post) in
        }
        getPosts()
    }
    
    @objc func textPosted(){
        if (postTextView.text != ""){
            newPosts(text: postTextView.text, username: "Anonymous", longitude: getLongitude, latitude: getLatitude)
        }
        postTextView.text = "what's on your mind"
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        postTextView.becomeFirstResponder()
        if postTextView.textColor == UIColor.lightGray {
            postTextView.text = ""
            postTextView.textColor = UIColor.black
        }
    }

    func textViewDidEndEditing(_ textView: UITextView) {
        if postTextView.text.isEmpty {
            postTextView.text = "What's on your mind?"
            postTextView.textColor = UIColor.lightGray
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return getPostV.count
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: reuseIdentifier, for: indexPath) as! FeedTableViewCell
        let post = getPostV[indexPath.row]
        cell.configure(for: post)
        cell.setNeedsUpdateConstraints()
        cell.selectionStyle = .none
        cell.delegate = self
        cell.rowNum = indexPath.row
        return cell
    }
    
    var getID: Int = 0
    
    
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        let cVC = CommentViewController()
//        cVC.getIDN = getPostV[indexPath.row].id
//        getID = getPostV[indexPath.row].id
//    }
    
    @objc func pulledToRefresh() {
        getPosts()
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            self.refreshControl.endRefreshing()
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}

extension MainFeedViewController: BackDelegate {
    func goBack(){
        
    }
}

extension MainFeedViewController: FeedTableViewCellDelegate{
    func didCommentButtonTapped(post: String) {
        let commentViewController = CommentViewController()
        let vc1 = FeedTableViewCell()
        commentViewController.getIDN = vc1.rowNum
        print (commentViewController.getIDN)

        navigationController?.pushViewController(commentViewController, animated: true)
    }
}

extension MainFeedViewController: FeedTableViewCellDelegate2{
    func didLikeButtonTapped(post: String) {
        let cv2 = CommentViewController()
        if (cv2.heartImage.image == UIImage(named: "Heart")){
            NetworkManager.like(vote: true){ (like) in
            }
        }
        if (cv2.heartImage.image == UIImage(named: "grayHeart")) {
            NetworkManager.like(vote: false){ (like) in
            }
        }
        getPosts()
    }
}


